import { LightningElement } from 'lwc';

/**
 * @slot sidebar
 */
export default class CommerceHitechThemeLayout extends LightningElement {}