import { LightningElement } from 'lwc';

export default class TestHitech extends LightningElement {}